//
//  ViewControllerDetail.m
//  demo_Movie
//
//  Created by Yi Hwei Huang on 2019/1/2.
//  Copyright © 2019 Yi Hwei Huang. All rights reserved.
//

#import "ViewControllerDetail.h"

@implementation ViewControllerDetail

@end
