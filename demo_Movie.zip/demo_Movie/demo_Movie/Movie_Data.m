//
//  movie_Data.m
//  demo_Movie
//
//  Created by Yi Hwei Huang on 2018/12/22.
//  Copyright © 2018 Yi Hwei Huang. All rights reserved.
//

#import "Movie_Data.h"

@implementation Movie_Data

@end
