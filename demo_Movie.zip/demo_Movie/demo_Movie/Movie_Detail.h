//
//  ViewControllerDetail.h
//  demo_Movie
//
//  Created by Yi Hwei Huang on 2019/1/2.
//  Copyright © 2019 Yi Hwei Huang. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ViewControllerDetail : NSObject

@end

NS_ASSUME_NONNULL_END
